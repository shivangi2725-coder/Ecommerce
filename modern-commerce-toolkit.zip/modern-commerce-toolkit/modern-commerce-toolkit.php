<?php
/**
 * Plugin Name: Modern Commerce Toolkit
 * Description: A lightweight WooCommerce extension that adds a polished product experience, quick-view modal, wishlist buttons, product badges, and a simple storefront shortcode.
 * Version: 1.0.0
 * Author: Open Source Contributor
 * License: GPL-2.0-or-later
 * Text Domain: modern-commerce-toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MCT_VERSION', '1.0.0' );
define( 'MCT_FILE', __FILE__ );
define( 'MCT_URL', plugin_dir_url( __FILE__ ) );

final class Modern_Commerce_Toolkit {

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_notice' ) );
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'woocommerce_after_shop_loop_item', array( $this, 'quick_view_button' ), 15 );
		add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'product_badge' ), 5 );
		add_action( 'woocommerce_single_product_summary', array( $this, 'wishlist_button' ), 35 );
		add_action( 'wp_footer', array( $this, 'quick_view_markup' ) );
		add_shortcode( 'mct_products', array( $this, 'products_shortcode' ) );

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		add_action( 'wp_ajax_mct_quick_view', array( $this, 'quick_view' ) );
		add_action( 'wp_ajax_nopriv_mct_quick_view', array( $this, 'quick_view' ) );
	}

	public function woocommerce_notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning"><p><strong>Modern Commerce Toolkit</strong> requires WooCommerce to be installed and active.</p></div>';
		}
	}

	public function assets() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		wp_enqueue_style(
			'mct-style',
			MCT_URL . 'assets/storefront.css',
			array(),
			MCT_VERSION
		);

		wp_enqueue_script(
			'mct-script',
			MCT_URL . 'assets/storefront.js',
			array( 'jquery' ),
			MCT_VERSION,
			true
		);

		wp_localize_script(
			'mct-script',
			'MCT_DATA',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'mct_quick_view' ),
				'currency' => get_woocommerce_currency_symbol(),
			)
		);
	}

	public function product_badge() {
		global $product;

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		$badge = '';
		if ( $product->is_on_sale() ) {
			$badge = get_option( 'mct_sale_badge', 'Sale' );
		} elseif ( $product->is_featured() ) {
			$badge = get_option( 'mct_featured_badge', 'Featured' );
		}

		if ( $badge ) {
			printf(
				'<span class="mct-badge">%s</span>',
				esc_html( $badge )
			);
		}
	}

	public function quick_view_button() {
		global $product;

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		printf(
			'<button class="mct-quick-view" type="button" data-product-id="%d" aria-label="%s">%s</button>',
			absint( $product->get_id() ),
			esc_attr( sprintf( 'Quick view %s', $product->get_name() ) ),
			esc_html__( 'Quick View', 'modern-commerce-toolkit' )
		);
	}

	public function wishlist_button() {
		global $product;

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		printf(
			'<button class="mct-wishlist" type="button" data-product-id="%d" aria-pressed="false">♡ <span>%s</span></button>',
			absint( $product->get_id() ),
			esc_html__( 'Add to wishlist', 'modern-commerce-toolkit' )
		);
	}

	public function quick_view_markup() {
		if ( is_admin() ) {
			return;
		}
		?>
		<div class="mct-modal" id="mct-modal" aria-hidden="true">
			<div class="mct-modal__backdrop"></div>
			<div class="mct-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="mct-modal-title">
				<button class="mct-modal__close" type="button" aria-label="Close">×</button>
				<div id="mct-modal-content">
					<div class="mct-loading">Loading…</div>
				</div>
			</div>
		</div>
		<?php
	}

	public function quick_view() {
		check_ajax_referer( 'mct_quick_view', 'nonce' );

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$product    = wc_get_product( $product_id );

		if ( ! $product ) {
			wp_send_json_error( array( 'message' => 'Product not found.' ), 404 );
		}

		ob_start();
		?>
		<div class="mct-quick-product">
			<div class="mct-quick-product__image">
				<?php echo wp_kses_post( $product->get_image( 'woocommerce_single' ) ); ?>
			</div>
			<div class="mct-quick-product__info">
				<p class="mct-eyebrow"><?php echo esc_html( wc_get_product_category_list( $product_id ) ); ?></p>
				<h2 id="mct-modal-title"><?php echo esc_html( $product->get_name() ); ?></h2>
				<div class="mct-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
				<div class="mct-description"><?php echo wp_kses_post( wpautop( $product->get_short_description() ) ); ?></div>
				<a class="mct-button" href="<?php echo esc_url( get_permalink( $product_id ) ); ?>">View product</a>
			</div>
		</div>
		<?php

		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	public function products_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'limit'   => 8,
				'columns' => 4,
				'orderby' => 'date',
				'order'   => 'DESC',
			),
			$atts,
			'mct_products'
		);

		$query = new WP_Query(
			array(
				'post_type'      => 'product',
				'posts_per_page' => max( 1, min( 24, absint( $atts['limit'] ) ) ),
				'orderby'        => sanitize_key( $atts['orderby'] ),
				'order'          => 'ASC' === strtoupper( $atts['order'] ) ? 'ASC' : 'DESC',
				'post_status'    => 'publish',
			)
		);

		ob_start();

		if ( $query->have_posts() ) {
			printf(
				'<div class="mct-product-grid mct-columns-%d">',
				max( 1, min( 6, absint( $atts['columns'] ) ) )
			);

			while ( $query->have_posts() ) {
				$query->the_post();
				$product = wc_get_product( get_the_ID() );

				if ( ! $product ) {
					continue;
				}
				?>
				<article class="mct-card">
					<a href="<?php the_permalink(); ?>" class="mct-card__image">
						<?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) ); ?>
					</a>
					<div class="mct-card__body">
						<h3><a href="<?php the_permalink(); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3>
						<div class="mct-card__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
						<button class="mct-quick-view" type="button" data-product-id="<?php echo absint( $product->get_id() ); ?>">Quick View</button>
					</div>
				</article>
				<?php
			}

			echo '</div>';
		} else {
			echo '<p>No products found.</p>';
		}

		wp_reset_postdata();

		return ob_get_clean();
	}

	public function admin_menu() {
		add_submenu_page(
			'woocommerce',
			'Modern Commerce Toolkit',
			'Modern Commerce Toolkit',
			'manage_woocommerce',
			'modern-commerce-toolkit',
			array( $this, 'settings_page' )
		);
	}

	public function register_settings() {
		register_setting(
			'mct_settings',
			'mct_sale_badge',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => 'Sale',
			)
		);

		register_setting(
			'mct_settings',
			'mct_featured_badge',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => 'Featured',
			)
		);
	}

	public function settings_page() {
		?>
		<div class="wrap">
			<h1>Modern Commerce Toolkit</h1>
			<p>A lightweight presentation layer for WooCommerce.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'mct_settings' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="mct_sale_badge">Sale badge</label></th>
						<td><input class="regular-text" id="mct_sale_badge" name="mct_sale_badge" value="<?php echo esc_attr( get_option( 'mct_sale_badge', 'Sale' ) ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="mct_featured_badge">Featured badge</label></th>
						<td><input class="regular-text" id="mct_featured_badge" name="mct_featured_badge" value="<?php echo esc_attr( get_option( 'mct_featured_badge', 'Featured' ) ); ?>"></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<hr>
			<h2>Shortcode</h2>
			<p>Use <code>[mct_products limit="8" columns="4"]</code> on any page to display a responsive product grid.</p>
		</div>
		<?php
	}
}

new Modern_Commerce_Toolkit();
