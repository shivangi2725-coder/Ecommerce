<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'mct_sale_badge' );
delete_option( 'mct_featured_badge' );
