=== Modern Commerce Toolkit ===
Contributors: open-source-contributor
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight WooCommerce extension adding quick view, product badges, wishlist UI, and a responsive product shortcode.

== Description ==

Modern Commerce Toolkit improves the WooCommerce storefront while leaving WooCommerce's core product, cart, checkout, and order functionality intact.

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/.
2. Activate the plugin.
3. Make sure WooCommerce is active.
4. Configure the plugin under WooCommerce > Modern Commerce Toolkit.

== Shortcode ==

[mct_products limit="8" columns="4"]

== License ==

GPL-2.0-or-later.
