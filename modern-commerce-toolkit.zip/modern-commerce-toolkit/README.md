# Modern Commerce Toolkit

A lightweight WooCommerce extension for improving the storefront experience without replacing WooCommerce's core cart, checkout, products, or order system.

## What it provides

- Quick-view modal for products
- Product badges for sale and featured products
- Lightweight wishlist UI
- Responsive product-grid shortcode
- Small WooCommerce admin settings page
- Vanilla CSS/JavaScript + WordPress APIs
- Nonces and sanitization for AJAX/settings handling
- No external services or API keys required

## Requirements

- WordPress 6.4+
- WooCommerce 8.0+
- PHP 7.4+

## Installation

1. Download or clone the repository.
2. Place the `modern-commerce-toolkit` folder in `wp-content/plugins/`.
3. Activate **Modern Commerce Toolkit** from WordPress → Plugins.
4. Ensure WooCommerce is active.
5. Configure badges under WooCommerce → Modern Commerce Toolkit.

## Shortcode

Display a product grid on any page:

`[mct_products limit="8" columns="4"]`

Supported attributes:

- `limit`: 1–24 products
- `columns`: 1–6 columns
- `orderby`: WordPress query ordering
- `order`: ASC or DESC

## Project status

This is an intentionally small, extensible foundation. The wishlist is currently a front-end preference stored in the page state; a production implementation can add persistent customer/user storage. Payment processing and order handling remain delegated to WooCommerce.

## Security

The plugin uses WordPress nonces for AJAX requests and sanitizes administrator settings. Product data is escaped before output. It does not collect or transmit customer data to third-party services.

## License

GPL-2.0-or-later.
